// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "KingdomGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class KINGDOM_API AKingdomGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
